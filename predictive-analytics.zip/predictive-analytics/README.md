# Predictive Analytics Using Historical Data

An end-to-end pipeline for forecasting future trends from historical time-series data — data cleaning, feature engineering, model training (regression + time series), evaluation, and visualization.

## Features

- **Data cleaning & preprocessing** — fills date gaps, caps outliers (IQR method), interpolates missing values
- **Feature engineering** — lag features, rolling statistics, calendar features
- **Three forecasting models compared:**
  - Linear Regression
  - Random Forest Regression
  - Holt-Winters triple exponential smoothing (implemented from scratch, no `statsmodels` dependency)
- **Evaluation metrics** — MAE, RMSE, MAPE, R²
- **Visualizations** — actual vs. predicted on a held-out test window, model accuracy comparison, and a forward forecast plot

## Getting Started

### Requirements

```bash
pip install -r requirements.txt
```

### Run

```bash
python forecasting_pipeline.py
```

This runs on built-in synthetic sample data (2 years of daily sales with trend, weekly/annual seasonality, missing values, and outliers) so it works out of the box.

### Using your own data

Open `forecasting_pipeline.py` and:

1. Replace `load_data()` with a call to load your CSV, e.g.:
   ```python
   def load_data():
       return pd.read_csv("your_file.csv")
   ```
2. Update `DATE_COL` and `TARGET_COL` at the top of the file to match your column names.
3. Adjust `FORECAST_HORIZON` to however many periods ahead you want to predict.

Your CSV needs at minimum a date column and a numeric target column.

## Output

Running the script produces (in `outputs/`):

| File | Description |
|---|---|
| `evaluation_plots.png` | Historical data + model predictions on the test window, and an accuracy bar chart |
| `future_forecast.png` | Forward-looking forecast beyond the available data |
| `model_comparison.csv` | MAE / RMSE / MAPE / R² for each model |
| `future_forecast.csv` | Forecasted values for the forecast horizon |

## Sample Results

On the synthetic sample data, model performance on the held-out 30-day test window:

| Model | MAE | RMSE | MAPE | R² |
|---|---|---|---|---|
| Linear Regression | 14.76 | 26.62 | 3.10% | 0.248 |
| Random Forest | 19.94 | 33.57 | 4.20% | -0.197 |
| Holt-Winters | 12.62 | 26.08 | 2.63% | 0.278 |

## Project Structure

```
.
├── forecasting_pipeline.py   # Main pipeline
├── requirements.txt
├── outputs/                  # Generated plots and CSVs
└── README.md
```

## License

MIT
